# QuartaJornada3Manha
Projeto elaborado no Grupo de Estudos dos Formadores
